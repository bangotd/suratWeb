<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <h5 class="card-header bg-primary text-white">Detail Arsip Surat</h5>
                <div class="card-body p-0">
                    <table class="table table-sm">
                        <tr>
                            <td width="150">Tanggal Surat</td>
                            <td> : <?php echo e($arsip->tgl_surat); ?></td>
                            
                        </tr>
                        <tr>
                            <td width="150">Title</td>
                            <td> : <?php echo e($arsip->title); ?></td>
                        </tr>
                        <tr>
                            <td width="150">Nomor Surat</td>
                            <td> : <?php echo e($arsip->nomor_surat); ?> </td>
                        </tr>
                    </table>
                        <div class="p-0" style="height:800px;">
                                <embed src="<?php echo e(Storage::url($arsip->file)); ?>" width="100%" height="100%"> </embed>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>