<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <h5 class="card-header bg-primary text-white">Surat Keluar</h5>
                <div class="card-body p-0">
                    <div class="row mb-3 p-3 mb-0">
                        <div class="col-md-6">
                            <form method="GET" aclass="form-inline">
                                <div class="input-group">
                                    <input type="text" name="search" value="<?php echo e(request()->search); ?>" class="form-control"
                                        placeholder="Search title/no. surat/TGL Surat(yyyy-m-d)"
                                        aria-label="Search name or ID Card" aria-describedby="basic-addon2"
                                        autocomplete="off" autofocus="on">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-danger"> Search </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <table class="table table-striped">
                        <tr>
                            <th>No.</th>
                            <th>TGL. Surat</th>
                            <th>Title</th>
                            <th>Nomor Surat</th>
                            <th>Kategori</th>
                            <th>Tool</th>
                        </tr>
                        <?php $no = 1;
                        ?>
                        <?php $__currentLoopData = $suratkeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e(date('d-m-Y', strtotime($item->tgl_surat))); ?></td>
                            <td><?php echo e($item->title); ?></td>
                            <td><?php echo e($item->nomor_surat); ?></td>
                            <td><?php echo e($item->category->name); ?></td>
                            
                            <td>
                                <a href="<?php echo e(url('arsip/detail/'.$item->id)); ?>" class="btn btn-sm btn-warning">Lihat</a>
                                <a href="<?php echo e(url('arsip/edit/'.$item->id)); ?>" class="btn btn-sm btn-primary">Edit</a>

                                <a href="#" class="btn btn-danger btn-sm" onclick="confirmDelete('<?php echo e($item->id); ?>')"
                                    title="Delete data"><i class="fa fa-trash"></i> Delete</a>
                                <form id="form-delete-<?php echo e($item->id); ?>" action="<?php echo e(url('arsip/'.$item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                </form>
                               
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                </div>
                <div class="card-footer text-muted">
                    <?php echo e($suratkeluar->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>